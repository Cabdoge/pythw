mylda=function(X, Y){
  n=nrow(X)
  p=ncol(X)
  ##对样本分类
  id1=which(Y==1)
  id0=which(Y==0)
  ##计算样本大小
  n1=length(id1)
  n0=length(id0)
  ##通过样本大小的比值计算先验概率
  prior_prop=log(n1/n0)
  ##计算不同分类下的均值
  mu1=colMeans(X[id1, ])
  mu0=colMeans(X[id0, ])
  ##计算不同分类的方差及总体方差
  S1=var(X[id1, ])
  S0=var(X[id0, ])
  S=((n1-1)*S1+(n0-1)*S0)/(n - 2)
  ##计算斜率k=S^-1*(mu1 - mu0)
  k=solve(S,(mu1-mu0))
  ##计算截距
  b=-0.5*t(mu1+mu0)%*%k+prior_prop
  beta=c(b,k)
  return(as.vector(beta))
}