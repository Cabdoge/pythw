
Loo_logit <- function(k){
  X1=cbind(1,X)
  beta=myglm(X[-k,],Y[-k])
  y_test=as.numeric(X1[k,]%*%beta>0)
  return(y_test)
}

##lda的留一法
Loo_lda=function(k){
  X1=cbind(1,X)
  beta=mylda(X[-k,],Y[-k])
  y_test=as.numeric(X1[k,]%*%beta>0)
  return(y_test)
}

##欧式距离法的留一法
Loo_dis=function(k){
  return(dissort(X[-k,],Y[-k],X[k,]))
}
