dissort=function(X,Y,Z){
  if(is.null(dim(Z))){
    Z = matrix(Z, nrow=1)
  } else {
    Z = as.matrix(Z)
  }
  ##对样本分类
  id1=which(Y==1)
  id0=which(Y==0)
  ##计算样本大小
  n1=length(id1)
  n0=length(id0)
  ##提取不同分类的样本
  X1=X[id1, ]
  X0=X[id0, ]
  ##计算距离的辅助函数
  calcdis=function(a,B){
    return(mean(sqrt(rowSums(t(t(B)-a)^2))))
  }
  ##计算样本距离
  d1=apply(Z,1,calcdis,B=X1)
  d0=apply(Z,1,calcdis,B=X0)
  y=(sign(d0 -d1)+1)/2
  return(as.numeric((d0-d1)>0))
}